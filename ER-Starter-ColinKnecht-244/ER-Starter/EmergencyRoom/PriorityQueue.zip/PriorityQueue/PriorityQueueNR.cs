﻿using PriorityQueue;
using System;
using System.Collections.Generic;

namespace PriorityQueueNR
{
    /*
    class MinHeap<T> where T : IComparable<T>
    {
        private List<T> array = new List<T>();
        public int Count { get { return array.Count; } }

        public void Add(T element)
        {
            // add element at end
            int currPos;
            bool done = false;
            array.Add(element);
            currPos = array.Count - 1;

            // move up as far as possible
            while (currPos > 0 && !done)
            {
                // integer division will drop any fraction and give the parent
                int parent = (currPos - 1) / 2;
                // if parent is larger than child, swap
                if (array[currPos].CompareTo(array[parent]) < 0)
                {
                    T tmp = array[currPos];
                    array[currPos] = array[parent];
                    array[parent] = tmp;
                    // set to parent
                    currPos = parent;
                }
                else
                {
                    done = true;
                }
            }
        }

        public T RemoveMin()
        {
            int currPos;
            bool done = false;
            // set the return value to the top of the heap
            T ret = array[0];

            // move the last element to the top
            array[0] = array[array.Count - 1];
            array.RemoveAt(array.Count - 1);

            // start at the top node
            currPos = 0;

            // move the top element down the list as far as possible, replacing the minimum child
            do
            {
                int min = currPos;
                int leftChild = 2 * currPos + 1;
                int rightChild = 2 * currPos + 2;

                // find whether the smaller of the two children is less than our 'loc'
                // first check left child
                if (leftChild < array.Count && array[leftChild].CompareTo(array[min]) < 0)
                    min = leftChild;
                // second check right child (note that 'min' may be left child)
                if (rightChild < array.Count && array[rightChild].CompareTo(array[min]) < 0)
                    min = rightChild;

                // if min didn't change, were done
                if (min == currPos)
                    done = true;
                else
                {
                    T tmp = array[currPos];
                    array[currPos] = array[min];
                    array[min] = tmp;
                    currPos = min;
                }
            } while (!done && currPos < array.Count);

            return ret;
        }

        public T Peek()
        {
            return array[0];
        }

    }
    */

   
    public class PriorityQueueNR<T>
    {
        internal class Node : IComparable<Node>
        {
            public int Priority;
            public T O;
            public int CompareTo(Node other)
            {
                return Priority.CompareTo(other.Priority);
            }
        }

        private MinHeap<Node> minHeap = new MinHeap<Node>();
        public int Count { get { return minHeap.Count; } }

        public void Add(int priority, T element)
        {
            minHeap.Add(new Node() { Priority = priority, O = element });
        }

        public T Remove()
        {
            return minHeap.RemoveMin().O;
        }

        public T Peek()
        {
            return minHeap.Peek().O;
        }

    }

    class Program { 
        static void zMain(string[] args)
        {
            PriorityQueueNR<string> myQueue = new PriorityQueueNR<string>();
            myQueue.Add(10, "ten");
            myQueue.Add(8, "eight");
            myQueue.Add(6, "six");
            myQueue.Add(12, "twelve");
            myQueue.Add(4, "four");
            myQueue.Add(9, "nine");
            myQueue.Add(110, "1-ten");
            myQueue.Add(108, "1-eight");
            myQueue.Add(106, "1-six");
            myQueue.Add(112, "1-twelve");
            myQueue.Add(104, "1-four");
            myQueue.Add(109, "1-nine");
            while (myQueue.Count > 0)
            {
                Console.WriteLine(myQueue.Remove());
            }
            Console.ReadLine();
        }
    }
}
